"""
seed.py — Krijon të dhëna fillestare në databazë.
Ekzekuto një herë: python seed.py
"""
from app.database import SessionLocal, engine
from app import models
from app.auth import hash_password

models.Base.metadata.create_all(bind=engine)

db = SessionLocal()

# Kontrollo nëse ka tashmë të dhëna
if db.query(models.User).first():
    print("✅ Databaza ka tashmë të dhëna. seed.py u anulua.")
    db.close()
    exit()

# ── USERS ──────────────────────────────────────────────
users = [
    models.User(fname="Artan",   lname="Kelmendi", email="admin@eveng.al",   hashed_password=hash_password("admin123"),   role="admin",   status="active"),
    models.User(fname="Blerina", lname="Emini",    email="manager@eveng.al", hashed_password=hash_password("manager123"), role="manager", status="active"),
    models.User(fname="Çlirim",  lname="Morina",   email="worker@eveng.al",  hashed_password=hash_password("worker123"),  role="worker",  status="active"),
    models.User(fname="Driton",  lname="Loxha",    email="viewer@eveng.al",  hashed_password=hash_password("viewer123"),  role="viewer",  status="active"),
]
db.add_all(users)
db.flush()

# ── PROJECTS ───────────────────────────────────────────
projects = [
    models.Project(name="Pallati Tirana",  location="Tiranë",  status="active", color="blue",   progress=65, created_by=users[0].id),
    models.Project(name="Shkolla Durrës",  location="Durrës",  status="active", color="green",  progress=40, created_by=users[1].id),
    models.Project(name="Hotel Sarandë",   location="Sarandë", status="paused", color="orange", progress=20, created_by=users[1].id),
    models.Project(name="Rruga Korçë",     location="Korçë",   status="done",   color="purple", progress=100,created_by=users[0].id),
]
db.add_all(projects)
db.flush()

# ── TASKS ──────────────────────────────────────────────
tasks_data = [
    ("Armatura kati 3",       1, "high", "10/06/2026", 0, 2),
    ("Inspektim betoni",      1, "med",  "12/06/2026", 0, 2),
    ("Instalim dritareve",    1, "low",  "15/06/2026", 0, 2),
    ("Lyerje fasade",         2, "med",  "08/06/2026", 1, 1),
    ("Kontrolli hidraulikës", 2, "high", "09/06/2026", 0, 2),
    ("Asfaltim parkingu",     2, "low",  "11/06/2026", 2, 2),
    ("Dokumentimi i planit",  3, "high", "07/06/2026", 3, 1),
    ("Raport final",          3, "med",  "06/06/2026", 0, 1),
    ("Dorëzimi çelësave",     4, "low",  "05/06/2026", 3, 0),
    ("Nënshkrim kontrate",    4, "high", "03/06/2026", 2, 0),
]
for title, col, prio, date, proj_idx, assign_idx in tasks_data:
    db.add(models.Task(
        title=title, column=col, priority=prio, due_date=date,
        project_id=projects[proj_idx].id,
        assigned_to=users[assign_idx].id,
        created_by=users[0].id,
    ))

# ── PLANS ──────────────────────────────────────────────
plans_data = [
    ("Kati Perdhe - A1", "v3.2", 0, 3, 12),
    ("Kati 1 - B2",      "v2.0", 0, 1, 8),
    ("Seksioni Strukturor","v5.1",0, 0, 20),
    ("Elektrik - MEP",   "v1.4", 0, 4, 5),
]
for name, ver, proj_idx, op, cl in plans_data:
    db.add(models.Plan(name=name, version=ver, project_id=projects[proj_idx].id,
                       uploaded_by=users[0].id, open_pins=op, closed_pins=cl))

# ── TEAM MEMBERS ───────────────────────────────────────
team = [
    models.TeamMember(name="Artan Kelmendi",  role="Menaxher Projekti",   initials="AK", color="#4f80ff", status="online"),
    models.TeamMember(name="Blerina Emini",   role="Inxhinier Civil",     initials="BE", color="#22c55e", status="online"),
    models.TeamMember(name="Çlirim Morina",   role="Arkitekt",            initials="CM", color="#f59e0b", status="away"),
    models.TeamMember(name="Driton Loxha",    role="Mbikëqyrës",          initials="DL", color="#ef4444", status="online"),
    models.TeamMember(name="Fatmire Nushi",   role="Inxhinier Elektrik",  initials="FN", color="#7c5cfc", status="away"),
    models.TeamMember(name="Gentian Hoxha",   role="Kontraktor",          initials="GH", color="#f97316", status="online"),
]
db.add_all(team)

db.commit()
db.close()
print("✅ Seed u krye! Databaza u populua me të dhëna fillestare.")
print("\n📋 Llogaritë demo:")
print("   admin@eveng.al   / admin123")
print("   manager@eveng.al / manager123")
print("   worker@eveng.al  / worker123")
print("   viewer@eveng.al  / viewer123")
