from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Text, Float
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base


class User(Base):
    __tablename__ = "users"

    id         = Column(Integer, primary_key=True, index=True)
    fname      = Column(String(100), nullable=False)
    lname      = Column(String(100), nullable=False)
    email      = Column(String(200), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role       = Column(String(20), default="worker")   # admin | manager | worker | viewer
    status     = Column(String(20), default="active")   # active | inactive
    created_at = Column(DateTime, default=datetime.utcnow)

    tasks_assigned = relationship("Task", back_populates="assigned_user", foreign_keys="Task.assigned_to")
    tasks_created  = relationship("Task", back_populates="creator",       foreign_keys="Task.created_by")


class Project(Base):
    __tablename__ = "projects"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(200), nullable=False)
    location    = Column(String(200), default="")
    description = Column(Text, default="")
    status      = Column(String(20), default="active")   # active | paused | done
    color       = Column(String(20), default="blue")
    progress    = Column(Float, default=0.0)
    created_by  = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at  = Column(DateTime, default=datetime.utcnow)

    tasks = relationship("Task", back_populates="project", cascade="all, delete-orphan")
    plans = relationship("Plan", back_populates="project", cascade="all, delete-orphan")


class Task(Base):
    __tablename__ = "tasks"

    id          = Column(Integer, primary_key=True, index=True)
    title       = Column(String(300), nullable=False)
    description = Column(Text, default="")
    column      = Column(Integer, default=1)             # 1=Hapur 2=Në Progres 3=Rishikim 4=Mbyllur
    priority    = Column(String(10), default="med")      # high | med | low
    due_date    = Column(String(20), default="")
    project_id  = Column(Integer, ForeignKey("projects.id"), nullable=False)
    assigned_to = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_by  = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at  = Column(DateTime, default=datetime.utcnow)

    project       = relationship("Project", back_populates="tasks")
    assigned_user = relationship("User", back_populates="tasks_assigned", foreign_keys=[assigned_to])
    creator       = relationship("User", back_populates="tasks_created",  foreign_keys=[created_by])


class Plan(Base):
    __tablename__ = "plans"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(200), nullable=False)
    version     = Column(String(50), default="v1.0")
    project_id  = Column(Integer, ForeignKey("projects.id"), nullable=False)
    uploaded_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    open_pins   = Column(Integer, default=0)
    closed_pins = Column(Integer, default=0)
    created_at  = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="plans")


class TeamMember(Base):
    __tablename__ = "team_members"

    id       = Column(Integer, primary_key=True, index=True)
    name     = Column(String(200), nullable=False)
    role     = Column(String(100), default="Anëtar")
    initials = Column(String(4), default="")
    color    = Column(String(10), default="#4f80ff")
    status   = Column(String(20), default="online")      # online | away
