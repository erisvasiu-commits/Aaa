from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional
from datetime import datetime


# ── AUTH ──────────────────────────────────────────────
class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: "UserOut"


# ── USER ──────────────────────────────────────────────
class UserCreate(BaseModel):
    fname: str
    lname: str
    email: EmailStr
    password: str
    role: str = "worker"

    @field_validator("role")
    @classmethod
    def valid_role(cls, v):
        if v not in ("admin", "manager", "worker", "viewer"):
            raise ValueError("Roli i pavlefshëm")
        return v

class UserUpdate(BaseModel):
    fname: Optional[str] = None
    lname: Optional[str] = None
    email: Optional[EmailStr] = None
    role: Optional[str] = None
    status: Optional[str] = None
    password: Optional[str] = None

class UserOut(BaseModel):
    id: int
    fname: str
    lname: str
    email: str
    role: str
    status: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ── PROJECT ───────────────────────────────────────────
class ProjectCreate(BaseModel):
    name: str
    location: str = ""
    description: str = ""
    status: str = "active"
    color: str = "blue"

class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    location: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    color: Optional[str] = None
    progress: Optional[float] = None

class ProjectOut(BaseModel):
    id: int
    name: str
    location: str
    description: str
    status: str
    color: str
    progress: float
    created_by: Optional[int]
    created_at: datetime

    model_config = {"from_attributes": True}


# ── TASK ──────────────────────────────────────────────
class TaskCreate(BaseModel):
    title: str
    description: str = ""
    column: int = 1
    priority: str = "med"
    due_date: str = ""
    project_id: int
    assigned_to: Optional[int] = None

class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    column: Optional[int] = None
    priority: Optional[str] = None
    due_date: Optional[str] = None
    assigned_to: Optional[int] = None

class TaskOut(BaseModel):
    id: int
    title: str
    description: str
    column: int
    priority: str
    due_date: str
    project_id: int
    assigned_to: Optional[int]
    created_by: Optional[int]
    created_at: datetime

    model_config = {"from_attributes": True}


# ── PLAN ──────────────────────────────────────────────
class PlanCreate(BaseModel):
    name: str
    version: str = "v1.0"
    project_id: int

class PlanUpdate(BaseModel):
    name: Optional[str] = None
    version: Optional[str] = None
    open_pins: Optional[int] = None
    closed_pins: Optional[int] = None

class PlanOut(BaseModel):
    id: int
    name: str
    version: str
    project_id: int
    uploaded_by: Optional[int]
    open_pins: int
    closed_pins: int
    created_at: datetime

    model_config = {"from_attributes": True}


# ── TEAM MEMBER ───────────────────────────────────────
class TeamMemberCreate(BaseModel):
    name: str
    role: str = "Anëtar"
    initials: str = ""
    color: str = "#4f80ff"
    status: str = "online"

class TeamMemberUpdate(BaseModel):
    name: Optional[str] = None
    role: Optional[str] = None
    initials: Optional[str] = None
    color: Optional[str] = None
    status: Optional[str] = None

class TeamMemberOut(BaseModel):
    id: int
    name: str
    role: str
    initials: str
    color: str
    status: str

    model_config = {"from_attributes": True}


# update forward ref
TokenResponse.model_rebuild()
