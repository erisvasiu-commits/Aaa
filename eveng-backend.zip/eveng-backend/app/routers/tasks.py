from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/tasks", tags=["Tasks"])


@router.get("/", response_model=List[schemas.TaskOut])
def list_tasks(
    project_id: Optional[int] = Query(None),
    column: Optional[int] = Query(None),
    assigned_to: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.get_current_user),
):
    q = db.query(models.Task)
    if project_id  is not None: q = q.filter(models.Task.project_id  == project_id)
    if column       is not None: q = q.filter(models.Task.column       == column)
    if assigned_to  is not None: q = q.filter(models.Task.assigned_to  == assigned_to)
    return q.order_by(models.Task.id).all()


@router.get("/{task_id}", response_model=schemas.TaskOut)
def get_task(
    task_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.get_current_user),
):
    t = db.query(models.Task).filter(models.Task.id == task_id).first()
    if not t:
        raise HTTPException(status_code=404, detail="Detyra nuk u gjet.")
    return t


@router.post("/", response_model=schemas.TaskOut, status_code=201)
def create_task(
    data: schemas.TaskCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.require_roles("admin", "manager", "worker")),
):
    proj = db.query(models.Project).filter(models.Project.id == data.project_id).first()
    if not proj:
        raise HTTPException(status_code=404, detail="Projekti nuk u gjet.")
    task = models.Task(**data.model_dump(), created_by=current_user.id)
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


@router.put("/{task_id}", response_model=schemas.TaskOut)
def update_task(
    task_id: int,
    data: schemas.TaskUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Detyra nuk u gjet.")

    # Workers can only update tasks assigned to them
    if current_user.role == "worker" and task.assigned_to != current_user.id:
        raise HTTPException(status_code=403, detail="Mund të ndryshoni vetëm detyrat tuaja.")
    if current_user.role == "viewer":
        raise HTTPException(status_code=403, detail="Akses i mohuar.")

    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(task, field, value)
    db.commit()
    db.refresh(task)
    return task


@router.delete("/{task_id}", status_code=204)
def delete_task(
    task_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.require_roles("admin", "manager")),
):
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Detyra nuk u gjet.")
    db.delete(task)
    db.commit()
