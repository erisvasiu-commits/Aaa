from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/users", tags=["Users"])

admin_only   = auth.require_roles("admin")
admin_manager = auth.require_roles("admin", "manager")


@router.get("/", response_model=List[schemas.UserOut])
def list_users(
    db: Session = Depends(get_db),
    _: models.User = Depends(admin_manager),
):
    return db.query(models.User).order_by(models.User.id).all()


@router.get("/{user_id}", response_model=schemas.UserOut)
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    # Users can view themselves; admins/managers can view anyone
    if current_user.id != user_id and current_user.role not in ("admin", "manager"):
        raise HTTPException(status_code=403, detail="Akses i mohuar.")
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Përdoruesi nuk u gjet.")
    return user


@router.post("/", response_model=schemas.UserOut, status_code=201)
def create_user(
    data: schemas.UserCreate,
    db: Session = Depends(get_db),
    _: models.User = Depends(admin_only),
):
    if db.query(models.User).filter(models.User.email == data.email.lower()).first():
        raise HTTPException(status_code=400, detail="Ky email ekziston tashmë.")
    user = models.User(
        fname=data.fname.strip(),
        lname=data.lname.strip(),
        email=data.email.lower(),
        hashed_password=auth.hash_password(data.password),
        role=data.role,
        status="active",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.put("/{user_id}", response_model=schemas.UserOut)
def update_user(
    user_id: int,
    data: schemas.UserUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user),
):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Përdoruesi nuk u gjet.")

    # Only admin can change other users' roles/status
    if current_user.id != user_id and current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Akses i mohuar.")

    if data.fname   is not None: user.fname  = data.fname.strip()
    if data.lname   is not None: user.lname  = data.lname.strip()
    if data.email   is not None: user.email  = data.email.lower()
    if data.password is not None and len(data.password) >= 6:
        user.hashed_password = auth.hash_password(data.password)
    if data.role    is not None and current_user.role == "admin": user.role   = data.role
    if data.status  is not None and current_user.role == "admin": user.status = data.status

    db.commit()
    db.refresh(user)
    return user


@router.delete("/{user_id}", status_code=204)
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(admin_only),
):
    if current_user.id == user_id:
        raise HTTPException(status_code=400, detail="Nuk mund të fshini llogarinë tuaj.")
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Përdoruesi nuk u gjet.")
    db.delete(user)
    db.commit()
