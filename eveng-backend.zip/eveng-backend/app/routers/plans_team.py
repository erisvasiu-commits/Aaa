from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app import models, schemas, auth

# ── PLANS ─────────────────────────────────────────────────────────────────────
plans_router = APIRouter(prefix="/plans", tags=["Plans"])


@plans_router.get("/", response_model=List[schemas.PlanOut])
def list_plans(
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.get_current_user),
):
    return db.query(models.Plan).order_by(models.Plan.id).all()


@plans_router.get("/{plan_id}", response_model=schemas.PlanOut)
def get_plan(
    plan_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.get_current_user),
):
    p = db.query(models.Plan).filter(models.Plan.id == plan_id).first()
    if not p:
        raise HTTPException(status_code=404, detail="Plani nuk u gjet.")
    return p


@plans_router.post("/", response_model=schemas.PlanOut, status_code=201)
def create_plan(
    data: schemas.PlanCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.require_roles("admin", "manager")),
):
    proj = db.query(models.Project).filter(models.Project.id == data.project_id).first()
    if not proj:
        raise HTTPException(status_code=404, detail="Projekti nuk u gjet.")
    plan = models.Plan(**data.model_dump(), uploaded_by=current_user.id)
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan


@plans_router.put("/{plan_id}", response_model=schemas.PlanOut)
def update_plan(
    plan_id: int,
    data: schemas.PlanUpdate,
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.require_roles("admin", "manager")),
):
    plan = db.query(models.Plan).filter(models.Plan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plani nuk u gjet.")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(plan, field, value)
    db.commit()
    db.refresh(plan)
    return plan


@plans_router.delete("/{plan_id}", status_code=204)
def delete_plan(
    plan_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.require_roles("admin")),
):
    plan = db.query(models.Plan).filter(models.Plan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plani nuk u gjet.")
    db.delete(plan)
    db.commit()


# ── TEAM MEMBERS ──────────────────────────────────────────────────────────────
team_router = APIRouter(prefix="/team", tags=["Team"])


@team_router.get("/", response_model=List[schemas.TeamMemberOut])
def list_team(
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.get_current_user),
):
    return db.query(models.TeamMember).order_by(models.TeamMember.id).all()


@team_router.post("/", response_model=schemas.TeamMemberOut, status_code=201)
def add_member(
    data: schemas.TeamMemberCreate,
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.require_roles("admin", "manager")),
):
    member = models.TeamMember(**data.model_dump())
    db.add(member)
    db.commit()
    db.refresh(member)
    return member


@team_router.put("/{member_id}", response_model=schemas.TeamMemberOut)
def update_member(
    member_id: int,
    data: schemas.TeamMemberUpdate,
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.require_roles("admin", "manager")),
):
    member = db.query(models.TeamMember).filter(models.TeamMember.id == member_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Anëtari nuk u gjet.")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(member, field, value)
    db.commit()
    db.refresh(member)
    return member


@team_router.delete("/{member_id}", status_code=204)
def delete_member(
    member_id: int,
    db: Session = Depends(get_db),
    _: models.User = Depends(auth.require_roles("admin")),
):
    member = db.query(models.TeamMember).filter(models.TeamMember.id == member_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Anëtari nuk u gjet.")
    db.delete(member)
    db.commit()
