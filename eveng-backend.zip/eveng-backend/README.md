# Project @ EV Eng — Backend API

Backend i ndërtuar me **Python + FastAPI + SQLite**.

---

## 📁 Struktura e Projektit

```
eveng-backend/
├── main.py                    # Entry point
├── requirements.txt           # Varësitë
├── seed.py                    # Popullo databazën me të dhëna demo
├── eveng.db                   # SQLite databaza (krijohet automatikisht)
└── app/
    ├── database.py            # Lidhja me SQLite
    ├── models.py              # Tabelat (User, Project, Task, Plan, TeamMember)
    ├── schemas.py             # Pydantic schemas (validim + serialiizm)
    ├── auth.py                # JWT tokens + kontroll rolesh
    └── routers/
        ├── auth_router.py     # POST /auth/login, /auth/register, GET /auth/me
        ├── users.py           # CRUD /users (admin)
        ├── projects.py        # CRUD /projects
        ├── tasks.py           # CRUD /tasks
        └── plans_team.py      # CRUD /plans dhe /team
```

---

## 🚀 Instalimi dhe Nisja

### 1. Kërkesat
- Python 3.10 ose më i ri
- pip

### 2. Instalo varësitë
```bash
pip install -r requirements.txt
```

### 3. Populo databazën (herën e parë)
```bash
python seed.py
```

### 4. Nis serverin
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Serveri niset te: **http://localhost:8000**

---

## 📖 Dokumentacioni API

Pasi ta nisësh serverin, hap:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

---

## 🔐 Llogaritë Demo

| Email | Fjalëkalimi | Roli |
|-------|-------------|------|
| admin@eveng.al | admin123 | 🔑 Admin |
| manager@eveng.al | manager123 | 👷 Menaxher |
| worker@eveng.al | worker123 | 🔧 Punonjës |
| viewer@eveng.al | viewer123 | 👁️ Vëzhgues |

---

## 🛡️ Sistemi i Roleve dhe Lejeve

| Endpoint | Admin | Manager | Worker | Viewer |
|----------|:-----:|:-------:|:------:|:------:|
| GET /users | ✅ | ✅ | ❌ | ❌ |
| POST /users | ✅ | ❌ | ❌ | ❌ |
| DELETE /users | ✅ | ❌ | ❌ | ❌ |
| GET /projects | ✅ | ✅ | ✅ | ✅ |
| POST /projects | ✅ | ✅ | ❌ | ❌ |
| DELETE /projects | ✅ | ❌ | ❌ | ❌ |
| GET /tasks | ✅ | ✅ | ✅ | ✅ |
| POST /tasks | ✅ | ✅ | ✅ | ❌ |
| PUT /tasks | ✅ | ✅ | vetëm të tyret | ❌ |
| DELETE /tasks | ✅ | ✅ | ❌ | ❌ |
| POST /plans | ✅ | ✅ | ❌ | ❌ |
| POST /team | ✅ | ✅ | ❌ | ❌ |

---

## 🌐 Endpoints të Plota

### Auth
```
POST /auth/register   — Regjistrim
POST /auth/login      — Login → merr JWT token
GET  /auth/me         — Kthe userin aktual
```

### Users
```
GET    /users         — Lista e të gjithë userëve
GET    /users/{id}    — Merr një user
POST   /users         — Krijo user të ri (admin)
PUT    /users/{id}    — Ndrysho userin
DELETE /users/{id}    — Fshi userin (admin)
```

### Projects
```
GET    /projects      — Lista e projekteve
GET    /projects/{id}
POST   /projects      — Krijo projekt
PUT    /projects/{id} — Ndrysho
DELETE /projects/{id} — Fshi (admin)
```

### Tasks
```
GET    /tasks?project_id=1&column=2&assigned_to=3
GET    /tasks/{id}
POST   /tasks
PUT    /tasks/{id}
DELETE /tasks/{id}
```

### Plans & Team
```
GET/POST/PUT/DELETE /plans
GET/POST/PUT/DELETE /team
```

---

## 🌍 Deployment

### Railway / Render (falas)
1. Ngarko kodin në GitHub
2. Krijo projekt të ri në railway.app ose render.com
3. Zgjidh repository-n
4. Vendos: `uvicorn main:app --host 0.0.0.0 --port $PORT`

### VPS (Ubuntu)
```bash
pip install -r requirements.txt
python seed.py
uvicorn main:app --host 0.0.0.0 --port 8000
```

Me **systemd** për ta mbajtur gjallë:
```ini
[Unit]
Description=EV Eng Backend
[Service]
WorkingDirectory=/var/www/eveng-backend
ExecStart=uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
[Install]
WantedBy=multi-user.target
```

---

## 🔧 Lidhja me Frontend

Në `fieldwire-app.html`, vendos URL-në e backend-it:
```javascript
const API_BASE = "http://localhost:8000";  // ose domeni yt

// Shembull login:
const res = await fetch(`${API_BASE}/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ email, password })
});
const { access_token, user } = await res.json();
```
