from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine
from app import models
from app.routers.auth_router import router as auth_router
from app.routers.users      import router as users_router
from app.routers.projects   import router as projects_router
from app.routers.tasks      import router as tasks_router
from app.routers.plans_team import plans_router, team_router

# Krijo të gjitha tabelat automatikisht
models.Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Project @ EV Eng — API",
    description="Backend API për sistemin e menaxhimit të projekteve ndërtimore.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS — lejo frontend-in të komunikojë me backend-in
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],        # Në prodhim vendos domenin e saktë
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Regjistro routers
app.include_router(auth_router)
app.include_router(users_router)
app.include_router(projects_router)
app.include_router(tasks_router)
app.include_router(plans_router)
app.include_router(team_router)


@app.get("/", tags=["Health"])
def root():
    return {
        "app": "Project @ EV Eng",
        "status": "running",
        "docs": "/docs",
    }

@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
